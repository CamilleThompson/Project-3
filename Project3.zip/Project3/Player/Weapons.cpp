#include <iostream>
#include <string>
#include "Weapons.h"
using namespace std;

Weapons::Weapons()
{
    int amount =0;
}
Weapons::Weapons(string name_)
{
    name_=name;
}