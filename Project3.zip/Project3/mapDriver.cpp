#include <iostream>
#include <string>
#include "Map.h"
#include "Map.cpp"
using namespace std;
int main()
{
    Map temp;
    temp.setPlanetName();
    cout << temp.getPlanetName() <<endl;

}